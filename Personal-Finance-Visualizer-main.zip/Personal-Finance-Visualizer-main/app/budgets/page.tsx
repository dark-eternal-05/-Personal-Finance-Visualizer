import { PlusCircle } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BudgetProgress } from "@/components/budget-progress"
import { BudgetComparisonChart } from "@/components/budget-comparison-chart"

export default function BudgetsPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tight">Budgets</h1>
          <Button asChild>
            <Link href="/budgets/new">
              <PlusCircle className="mr-2 h-4 w-4" />
              Set New Budget
            </Link>
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
          <Card className="lg:col-span-4">
            <CardHeader>
              <CardTitle>Budget vs. Actual</CardTitle>
              <CardDescription>Compare your budget with actual spending</CardDescription>
            </CardHeader>
            <CardContent>
              <BudgetComparisonChart />
            </CardContent>
          </Card>
          <Card className="lg:col-span-3">
            <CardHeader>
              <CardTitle>Budget Progress</CardTitle>
              <CardDescription>Track your monthly budget progress</CardDescription>
            </CardHeader>
            <CardContent>
              <BudgetProgress />
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Budget History</CardTitle>
            <CardDescription>Track how your spending compares to budgets over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center text-muted-foreground py-8">
              <p>Historical budget data will appear here as you continue to use the app.</p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
