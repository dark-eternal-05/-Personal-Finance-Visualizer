"use client"

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "@/components/ui/chart"
import { getBudgetStatus } from "@/lib/data"

export function BudgetComparisonChart() {
  // Current month (June 2023 for demo)
  const budgetData = getBudgetStatus(6, 2023)
    .filter((budget) => budget.spent > 0)
    .map((budget) => ({
      name: budget.categoryName,
      budgeted: budget.budgeted,
      spent: budget.spent,
      color: budget.categoryColor,
    }))

  return (
    <ResponsiveContainer width="100%" height={350}>
      <BarChart data={budgetData} layout="vertical">
        <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
        <XAxis type="number" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `$${value}`} />
        <YAxis dataKey="name" type="category" width={100} fontSize={12} tickLine={false} axisLine={false} />
        <Tooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload
              return (
                <div className="rounded-lg border bg-background p-2 shadow-sm">
                  <div className="grid gap-2">
                    <div className="font-bold">{data.name}</div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex flex-col">
                        <span className="text-[0.70rem] uppercase text-muted-foreground">Budgeted</span>
                        <span className="font-bold">${data.budgeted}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[0.70rem] uppercase text-muted-foreground">Spent</span>
                        <span className="font-bold">${data.spent}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            }
            return null
          }}
        />
        <Legend />
        <Bar
          dataKey="budgeted"
          name="Budget"
          fill="currentColor"
          className="fill-muted-foreground/30"
          radius={[0, 4, 4, 0]}
        />
        <Bar dataKey="spent" name="Actual" fill="currentColor" className="fill-primary" radius={[0, 4, 4, 0]} />
      </BarChart>
    </ResponsiveContainer>
  )
}
