"use client"
import { Progress } from "@/components/ui/progress"
import { getBudgetStatus } from "@/lib/data"

export function BudgetProgress() {
  // Current month (June 2023 for demo)
  const budgetStatuses = getBudgetStatus(6, 2023)

  return (
    <div className="space-y-4">
      {budgetStatuses.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-40 text-center">
          <p className="text-muted-foreground">No budgets set for this month</p>
        </div>
      ) : (
        budgetStatuses.map((budget) => (
          <div key={budget.id} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: budget.categoryColor }} />
                <span className="font-medium">{budget.categoryName}</span>
              </div>
              <div className="text-sm font-medium">
                ${budget.spent.toFixed(2)} / ${budget.budgeted.toFixed(2)}
              </div>
            </div>
            <Progress
              value={Math.min(budget.percentage, 100)}
              className={`h-2 ${
                budget.status === "over"
                  ? "bg-destructive/20"
                  : budget.status === "warning"
                    ? "bg-amber-100 dark:bg-amber-900/20"
                    : "bg-emerald-100 dark:bg-emerald-900/20"
              }`}
              indicatorClassName={
                budget.status === "over"
                  ? "bg-destructive"
                  : budget.status === "warning"
                    ? "bg-amber-500"
                    : "bg-emerald-500"
              }
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>
                {budget.remaining > 0 ? (
                  <span className="text-emerald-600 dark:text-emerald-400">${budget.remaining.toFixed(2)} left</span>
                ) : (
                  <span className="text-destructive">${Math.abs(budget.remaining).toFixed(2)} over budget</span>
                )}
              </span>
              <span>{budget.percentage.toFixed(1)}% used</span>
            </div>
          </div>
        ))
      )}
    </div>
  )
}
