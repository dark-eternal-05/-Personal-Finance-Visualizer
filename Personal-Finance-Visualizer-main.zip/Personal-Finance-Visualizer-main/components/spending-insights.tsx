"use client"

import { TrendingDown, TrendingUp, AlertTriangle, BarChart2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { getSpendingInsights } from "@/lib/data"

export function SpendingInsights() {
  // Current month (June 2023 for demo)
  const insights = getSpendingInsights(6, 2023)

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Monthly Comparison</CardTitle>
          <CardDescription>Compared to last month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            {insights.monthlyChangePercentage > 0 ? (
              <>
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-100 text-rose-600 dark:bg-rose-900/20 dark:text-rose-400">
                  <TrendingUp className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-sm font-medium">Spending increased</div>
                  <div className="text-xl font-bold text-rose-600 dark:text-rose-400">
                    +{insights.monthlyChangePercentage.toFixed(1)}%
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400">
                  <TrendingDown className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-sm font-medium">Spending decreased</div>
                  <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                    {Math.abs(insights.monthlyChangePercentage).toFixed(1)}%
                  </div>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {insights.overBudgetCategories.length > 0 && (
        <Card className="border-destructive/50">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <CardTitle className="text-base font-medium">Over Budget</CardTitle>
            </div>
            <CardDescription>Categories where you've exceeded your budget</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {insights.overBudgetCategories.map((category) => (
              <div key={category.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.categoryColor }} />
                    <span className="font-medium">{category.categoryName}</span>
                  </div>
                  <div className="text-destructive text-sm font-medium">{category.percentage.toFixed(0)}% spent</div>
                </div>
                <Progress value={100} className="h-2 bg-destructive/20" indicatorClassName="bg-destructive" />
                <div className="text-xs text-muted-foreground">
                  ${category.spent.toFixed(2)} / ${category.budgeted.toFixed(2)}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <BarChart2 className="h-4 w-4" />
            <CardTitle className="text-base font-medium">Top Expenses</CardTitle>
          </div>
          <CardDescription>Your biggest spending categories this month</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {insights.topExpenseCategories.map((category) => (
            <div key={category.id} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: category.color }} />
                  <span className="font-medium">{category.name}</span>
                </div>
                <div className="text-sm font-medium">${category.value.toFixed(2)}</div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
