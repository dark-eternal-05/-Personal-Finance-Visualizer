// Transaction Types
export type TransactionType = "income" | "expense"

// Category Types
export type Category = {
  id: string
  name: string
  type: TransactionType
  icon?: string
  color: string
}

// Transaction Types
export type Transaction = {
  id: string
  description: string
  amount: number
  date: string
  type: TransactionType
  categoryId: string
}

// Budget Types
export type Budget = {
  id: string
  categoryId: string
  amount: number
  month: number
  year: number
}

// Predefined Categories
export const categories: Category[] = [
  // Income Categories
  {
    id: "inc-salary",
    name: "Salary",
    type: "income",
    color: "#22c55e", // Green
  },
  {
    id: "inc-freelance",
    name: "Freelance",
    type: "income",
    color: "#3b82f6", // Blue
  },
  {
    id: "inc-investments",
    name: "Investments",
    type: "income",
    color: "#f59e0b", // Amber
  },
  {
    id: "inc-gifts",
    name: "Gifts",
    type: "income",
    color: "#ec4899", // Pink
  },
  {
    id: "inc-other",
    name: "Other Income",
    type: "income",
    color: "#8b5cf6", // Violet
  },

  // Expense Categories
  {
    id: "exp-housing",
    name: "Housing",
    type: "expense",
    color: "#ef4444", // Red
  },
  {
    id: "exp-food",
    name: "Food",
    type: "expense",
    color: "#f97316", // Orange
  },
  {
    id: "exp-transport",
    name: "Transportation",
    type: "expense",
    color: "#84cc16", // Lime
  },
  {
    id: "exp-utilities",
    name: "Utilities",
    type: "expense",
    color: "#06b6d4", // Cyan
  },
  {
    id: "exp-healthcare",
    name: "Healthcare",
    type: "expense",
    color: "#14b8a6", // Teal
  },
  {
    id: "exp-entertainment",
    name: "Entertainment",
    type: "expense",
    color: "#a855f7", // Purple
  },
  {
    id: "exp-shopping",
    name: "Shopping",
    type: "expense",
    color: "#d946ef", // Fuchsia
  },
  {
    id: "exp-education",
    name: "Education",
    type: "expense",
    color: "#0ea5e9", // Sky
  },
  {
    id: "exp-personal",
    name: "Personal Care",
    type: "expense",
    color: "#f43f5e", // Rose
  },
  {
    id: "exp-other",
    name: "Other Expenses",
    type: "expense",
    color: "#6b7280", // Gray
  },
]

// Sample Transactions
export const transactions: Transaction[] = [
  {
    id: "1",
    description: "Salary",
    amount: 4350,
    date: "2023-06-01",
    type: "income",
    categoryId: "inc-salary",
  },
  {
    id: "2",
    description: "Rent",
    amount: 1200,
    date: "2023-06-02",
    type: "expense",
    categoryId: "exp-housing",
  },
  {
    id: "3",
    description: "Groceries",
    amount: 150.44,
    date: "2023-06-05",
    type: "expense",
    categoryId: "exp-food",
  },
  {
    id: "4",
    description: "Electricity Bill",
    amount: 85,
    date: "2023-06-10",
    type: "expense",
    categoryId: "exp-utilities",
  },
  {
    id: "5",
    description: "Internet",
    amount: 79,
    date: "2023-06-15",
    type: "expense",
    categoryId: "exp-utilities",
  },
  {
    id: "6",
    description: "Dinner with friends",
    amount: 65.5,
    date: "2023-06-18",
    type: "expense",
    categoryId: "exp-food",
  },
  {
    id: "7",
    description: "Streaming services",
    amount: 25,
    date: "2023-06-20",
    type: "expense",
    categoryId: "exp-entertainment",
  },
  {
    id: "8",
    description: "Gas",
    amount: 45,
    date: "2023-06-22",
    type: "expense",
    categoryId: "exp-transport",
  },
  {
    id: "9",
    description: "Freelance project",
    amount: 850,
    date: "2023-06-25",
    type: "income",
    categoryId: "inc-freelance",
  },
  {
    id: "10",
    description: "Clothes shopping",
    amount: 120,
    date: "2023-06-27",
    type: "expense",
    categoryId: "exp-shopping",
  },
]

// Sample Budgets
export const budgets: Budget[] = [
  {
    id: "1",
    categoryId: "exp-housing",
    amount: 1300,
    month: 6,
    year: 2023,
  },
  {
    id: "2",
    categoryId: "exp-food",
    amount: 500,
    month: 6,
    year: 2023,
  },
  {
    id: "3",
    categoryId: "exp-transport",
    amount: 200,
    month: 6,
    year: 2023,
  },
  {
    id: "4",
    categoryId: "exp-utilities",
    amount: 200,
    month: 6,
    year: 2023,
  },
  {
    id: "5",
    categoryId: "exp-entertainment",
    amount: 150,
    month: 6,
    year: 2023,
  },
  {
    id: "6",
    categoryId: "exp-shopping",
    amount: 200,
    month: 6,
    year: 2023,
  },
  {
    id: "7",
    categoryId: "exp-personal",
    amount: 100,
    month: 6,
    year: 2023,
  },
  {
    id: "8",
    categoryId: "exp-healthcare",
    amount: 150,
    month: 6,
    year: 2023,
  },
]

// Helper functions
export function getCategoryById(id: string): Category | undefined {
  return categories.find((category) => category.id === id)
}

export function getTransactionsByCategory(categoryId: string): Transaction[] {
  return transactions.filter((transaction) => transaction.categoryId === categoryId)
}

export function getBudgetByCategory(categoryId: string, month: number, year: number): Budget | undefined {
  return budgets.find((budget) => budget.categoryId === categoryId && budget.month === month && budget.year === year)
}

export function getTransactionsByMonth(month: number, year: number): Transaction[] {
  return transactions.filter((transaction) => {
    const date = new Date(transaction.date)
    return date.getMonth() + 1 === month && date.getFullYear() === year
  })
}

export function getTotalExpensesByCategory(categoryId: string, month: number, year: number): number {
  const filteredTransactions = transactions.filter((transaction) => {
    const date = new Date(transaction.date)
    return (
      transaction.categoryId === categoryId &&
      transaction.type === "expense" &&
      date.getMonth() + 1 === month &&
      date.getFullYear() === year
    )
  })

  return filteredTransactions.reduce((total, transaction) => total + transaction.amount, 0)
}

export function getMonthlyIncome(month: number, year: number): number {
  const filteredTransactions = transactions.filter((transaction) => {
    const date = new Date(transaction.date)
    return transaction.type === "income" && date.getMonth() + 1 === month && date.getFullYear() === year
  })

  return filteredTransactions.reduce((total, transaction) => total + transaction.amount, 0)
}

export function getMonthlyExpenses(month: number, year: number): number {
  const filteredTransactions = transactions.filter((transaction) => {
    const date = new Date(transaction.date)
    return transaction.type === "expense" && date.getMonth() + 1 === month && date.getFullYear() === year
  })

  return filteredTransactions.reduce((total, transaction) => total + transaction.amount, 0)
}

export function getCategoryExpenseData(month: number, year: number) {
  const expenseCategories = categories.filter((category) => category.type === "expense")

  return expenseCategories
    .map((category) => {
      const totalExpense = getTotalExpensesByCategory(category.id, month, year)
      return {
        name: category.name,
        value: totalExpense,
        color: category.color,
        id: category.id,
      }
    })
    .filter((item) => item.value > 0)
}

export function getBudgetStatus(month: number, year: number) {
  return budgets
    .filter((budget) => budget.month === month && budget.year === year)
    .map((budget) => {
      const category = getCategoryById(budget.categoryId)
      const spent = getTotalExpensesByCategory(budget.categoryId, month, year)
      const remaining = budget.amount - spent
      const percentage = (spent / budget.amount) * 100

      return {
        id: budget.id,
        categoryId: budget.categoryId,
        categoryName: category?.name || "Unknown",
        categoryColor: category?.color || "#000000",
        budgeted: budget.amount,
        spent,
        remaining,
        percentage,
        status: percentage > 100 ? "over" : percentage > 85 ? "warning" : "good",
      }
    })
}

export function getSpendingInsights(month: number, year: number) {
  const currentMonthExpenses = getMonthlyExpenses(month, year)
  const previousMonth = month === 1 ? 12 : month - 1
  const previousYear = month === 1 ? year - 1 : year
  const previousMonthExpenses = getMonthlyExpenses(previousMonth, previousYear)

  const changePercentage = previousMonthExpenses
    ? ((currentMonthExpenses - previousMonthExpenses) / previousMonthExpenses) * 100
    : 0

  const budgetData = getBudgetStatus(month, year)
  const overBudgetCategories = budgetData.filter((item) => item.status === "over")
  const nearBudgetCategories = budgetData.filter((item) => item.status === "warning")

  const categoryExpenses = getCategoryExpenseData(month, year)
  const topCategories = [...categoryExpenses].sort((a, b) => b.value - a.value).slice(0, 3)

  return {
    monthlyChangePercentage: changePercentage,
    overBudgetCategories,
    nearBudgetCategories,
    topExpenseCategories: topCategories,
  }
}
